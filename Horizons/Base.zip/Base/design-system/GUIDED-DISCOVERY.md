# Horizons — Guided Discovery Methodology

**Status: CANONICAL / PEDAGOGY SOURCE OF TRUTH**

This file governs how Horizons teaches. The core methodology is series-wide; level-specific learner-language rules are explicitly scoped below. Visual/structural rules live in `CANONICAL-STYLE.md`.

## 1. Core learning cycle

Horizons normally teaches through:

**context → noticing → guided analysis → clarification → controlled practice → communicative use → real-world transfer**

Students meet meaningful language before receiving a full rule. They inspect visible evidence, answer guided questions, test the pattern and then use it for a purpose.

Guided Discovery is not unsupported guessing. The context must contain enough evidence for the intended conclusion.

## 2. Level-appropriate learner language

Learner-facing English must match what the learner has actually met in that book, not merely what a broad CEFR descriptor says they could know.

Before approving newly authored material, audit support language against preceding pages. Instructions, discovery prompts and role descriptions must not become a hidden vocabulary syllabus.

### Early-A1 rule — current A1 book

For the first units of A1, learner-facing English is deliberately much simpler than natural adult English.

Use this priority for newly authored language:

1. exact language already taught or already used in Horizons A1;
2. the current lesson target;
3. a transparent Spanish cognate/near-cognate when a support word is unavoidable;
4. an unavoidable new noun whose meaning is immediately obvious from an image or functional artifact.

If a non-target word, phrase or construction fits none of these, simplify or remove it.

#### Spanish bridge

Early A1 may intentionally prefer a literal or Spanish-parallel English structure over a more idiomatic native-English collocation when the literal form is clear and does not teach a false core grammar rule.

This can produce **borderline unnatural but comprehensible English**. Do not automatically naturalize it.

Examples:

- `What is your city?` before `What city do you live in?`;
- `What city?` / `Is it big?` before `What is it like?`;
- `What information? Choose five.` before a longer professional-style instruction;
- `Student A: ask and write. Student B: answer.` before language such as `role-play`, `staff member`, `customer` or `swap roles`.

The goal is controlled English with the smallest possible distance from structures a Spanish-speaking beginner can already process.

#### Stable instruction bank

Once an instruction verb/frame is established, reuse it instead of adding synonyms for variety. Typical early items include:

`read · listen · look · match · complete · find · write · choose · work in pairs · ask · answer · spell · say · guess`

Short fragments are acceptable when they reduce language load without ambiguity, for example `Capital letter?`, `What information?` or `Form complete?`.

Outside the lesson target, the preferred number of new learner-facing support words is **zero**. Authenticity never justifies a hidden vocabulary syllabus.

These early-A1 simplifications are **not automatically applied unchanged to future higher-level books**. Each book should establish its own cumulative language ceiling while preserving the same principle: support language should not outrun the learning sequence.

## 3. Context and evidence

Target language should first appear in meaningful context: a conversation, reading, listening, profile, message, form, schedule, map, ticket, menu, review, real-world interface or another recognizable situation.

The context must do pedagogical work. It should contain the examples learners need to inspect rather than serving as decoration.

Use one strong source of evidence when one is sufficient. Do not repeat identical information in a dialogue, form, table and caption merely to make the page feel complete.

## 4. Discovery questions

Discovery questions are explicit, evidence-based and as simple as the learner's current English allows.

They should direct attention to form, meaning, use, word order or convention without adding unnecessary metalanguage.

For early A1, reduced wording may be better:

- `I: am, is or are?`
- `Name: capital letter?`
- `Email: capital letter?`
- `What question is for the country?`

At later levels, questions may become more natural and analytical as long as the wording itself is accessible.

A discovery question does **not** automatically require an answer line, checkbox, multiple-choice option or other response space. If the intended classroom behavior is oral noticing, teacher-led analysis, pair discussion or mental comparison, the question alone may be the complete exercise. Add a visible response affordance only when learners are actually expected to record or select a response on the page.

## 5. Minimal sufficient scaffolding

Add support only when it makes the intended discovery or task possible.

Remove support when it:

- repeats visible evidence;
- gives away the answer unnecessarily;
- creates page crowding;
- introduces more language than the task itself;
- invents a response behavior the task does not require.

Removing one scaffold does not authorize replacing it with another. If answer choices are removed, do not automatically add answer lines. If a label is removed, do not invent a substitute heading. Treat the resulting simpler task as intentional unless another support element is explicitly needed.

A simple cognitive task can become difficult because of a complex instruction. Language simplicity is part of scaffolding.

### Task depth is not instruction length

Do **not** equate a more substantial activity with a longer learner-facing instruction.

When a task needs more depth, add depth through what the learner actually does: richer context, meaningful choices, information exchange, physical objects, a real artifact, repetition with variation, a concrete outcome or transfer to the learner's own life. Do not automatically add prose explaining every turn, condition or obvious classroom behavior.

Use this division of labor:

- the **instruction line** names the task in the shortest established language that is sufficient;
- the **model/example** shows the target exchange or expected product;
- **steps** appear only when the learner genuinely needs them to perform the task;
- the **visual, artifact or layout** carries information that does not need to be restated in English;
- the **teacher/classroom routine** may supply obvious behaviors that do not need to be printed.

A task can therefore be pedagogically rich while its instruction is only `Work in pairs.` If the model and visible task structure make the procedure clear, do not expand that line into a paragraph.

For early A1, prefer essential procedure over exhaustive procedure. For example:

- `Work in pairs.` + a model exchange + `Student A: choose a number. Ask. Student B: answer.`
- not `Work in pairs. Student A chooses a number, does not say the item, asks about it, repeats six times, then Student B changes roles...` when those extra directions are inferable or nonessential.

Likewise, freer transfer should usually become **more open**, not more scripted. `Use your real bag. Choose five items and practice a conversation.` is preferable to a long sequence that tells learners exactly where to put every item, how many turns to take, when to swap roles and what to write unless those details are genuinely necessary to the learning outcome.

**Authoring rule:** when asked to make an activity more elaborate, first elaborate the **task design**, not the **instruction language**.

## 6. Controlled and communicative practice

Learners need controlled practice before freer use when the target warrants it. Useful formats include choosing, matching, completing, ordering, categorizing, correcting and short transformations.

Several short exercises are preferred when they form one connected progression rather than unrelated worksheet items.

Pairwork should add genuine value through retrieval, comparison, information exchange, checking, decision-making or rehearsal. Do not add pairwork when both students merely read identical answers.

## 7. Lesson-letter roles

### Lesson A — Grammar and/or Vocabulary

Introduce core language in context, guide noticing, clarify concisely, provide controlled practice and finish with short communicative use.

### Lesson B — Reading/Listening with Vocabulary

The receptive text/audio carries the lesson. Vocabulary supports comprehension and later use without displacing the receptive skill.

#### HORIZONS ON AIR — recurring listening-show identity

`HORIZONS ON AIR` is the official recurring show identity for substantial listening-led Horizons lessons. Use the same show name across the book so learners recognize the feature immediately, while each episode receives its own short title.

The **identity repeats; the format does not have to**. An episode may use street interviews, a studio conversation, a host with guests, short field segments, phone calls, vox-pop answers or another believable audio-show format. Do not force the same host, cast, setting or interaction pattern across lessons.

When a Lesson B is listening-led, one longer `HORIZONS ON AIR` track may act as the spine of the two-page lesson. Reuse the same track across several tasks rather than fragmenting the lesson into unrelated mini-listenings. A useful progression is:

**first listen for the main situation → listen again for specific information → inspect language from the same audio → controlled practice → communicative/real-world transfer**.

The show should feel produced and adult through voice variety, a short recurring sting, light ambient sound, photography and authentic artifacts. **Do not create that sense of production by increasing learner-facing printed language complexity.** The early-A1 cumulative ceiling governs instructions, questions, labels and expected learner production; it does **not** require the receptive audio itself to sound unnaturally minimal.

For early A1, HORIZONS ON AIR may use natural **A1–A2 conversational English**, with occasional higher-level chunks, paraphrases or distractors when they are supported by context and are not essential to completing the task. Core target language and answer-bearing information must remain clear and recoverable. Extra language may add realism, personality and listening tolerance, but learners should not need to understand every word to succeed.

Do not write HORIZONS ON AIR as a chain of bare textbook prompts and one-line answers. Natural greetings, reactions, reasons, small talk, clarification, paraphrase and one or two plausible distractors are welcome when they make the interaction believable without obscuring the task.

The visible feature should use the official `HORIZONS ON AIR` name plus the episode title, not a generic genre label. Minor pronunciation tracks or tiny one-off audio drills do not need the full show identity; it is for listening features that carry meaningful lesson content.

### Lesson C — Grammar and/or Vocabulary

Use the same discovery philosophy as Lesson A with a different context/composition. Avoid mechanically repeating the same page pattern.

### Lesson D — Speaking or Writing through a real situation

Prepare learners for a productive outcome with a role, reason to communicate, information to obtain/give, a functional artifact when useful and a concrete result.

**Real-world complexity must not become language complexity.** A sophisticated situation may be represented through photography, labels and artifacts while the printed English remains controlled at the learner's current level.

## 8. Real-world artifacts

Forms, chats, maps, schedules, tickets, menus, reviews and similar interfaces must be functional. Learners should read, interpret, complete, respond to or use them.

Use only as much real-world terminology as the learner can currently process. Authenticity comes from the situation and function, not from reproducing every word a real business or app would use.

A recognizable artifact may carry much of the situational meaning visually. Use its familiar structure, field rhythm, message alignment or interface hierarchy to reduce the amount of explanatory English required. Visual authenticity should lower the language burden, not add another layer of vocabulary.

## 9. Back-of-book practice

Grammar Reference/Practice and Vocabulary Practice provide deeper consolidation than fits comfortably in a two-page lesson.

Grammar practice should move from familiar examples to concise clarification and practice. Vocabulary practice should recycle vocabulary through recognition, classification, association, contextual use and purposeful pairwork where useful.

## 10. Cumulative language audit

Before approving newly authored material, compare learner-facing words/constructions with the actual preceding pages of that book.

For each non-target item ask:

- Has the learner already seen this exact word/frame?
- Can an earlier wording do the same job?
- At early A1, is it a transparent Spanish cognate or visually obvious noun?
- Am I adding a native-English collocation only because it sounds better?
- Does the learner need this English to learn the target, or only to understand my instruction?

If it exists only for the instruction, simplify the instruction.

Do not treat teacher knowledge, a generic CEFR list or vocabulary from future units as prior teaching.

## 11. Series language conventions

- American English is the default language standard unless a book explicitly requires otherwise.
- Avoid a recurring fictional cast as a default series device; use characters/situations because the lesson needs them.
- Real public figures should be used selectively, only when widely recognizable and pedagogically useful.

## 12. Authoring approval test

Before approving a lesson, verify:

1. Where does the learner first meet the target language in context?
2. What exact evidence can the learner inspect?
3. What question directs attention to the intended pattern/use?
4. Is every scaffold necessary?
5. Does every visible response affordance match an actual expected learner action?
6. If a scaffold was removed, did the page remain simple rather than silently replacing it with another?
7. Where is the discovery clarified?
8. What controlled task lets the learner test it?
9. Where does pairwork add genuine value?
10. What does the learner ultimately accomplish?
11. Which learner-facing words/constructions are new on this page?
12. Are new non-target items genuinely necessary and level-appropriate?
13. Did any rewrite become more idiomatic but less accessible than the book's established register?
14. If an activity became more substantial, did the **task** become richer without the **instruction** becoming needlessly longer?
15. Can any printed procedural sentence be removed because the model, visual, artifact or classroom routine already makes it clear?

When native-like phrasing conflicts with the deliberate language progression, **the progression wins**.
